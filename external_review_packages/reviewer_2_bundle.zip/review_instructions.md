# Independent Direction P v2 construct review — reviewer 2

Use only this offline ZIP. Do not access the repository, source code, generator,
hidden key, audit reports, another reviewer's files, ChatGPT, an LLM, a vision
model, or any automated answer tool. Do not discuss the review with the other
reviewer. The author and build agent cannot answer review items for you.

Review every row in `review_packet.csv`, opening its bundle-local `image_path`.
Enter every answer in `response_template.csv`; do not edit `review_packet.csv`.
Each judgment must be exactly `yes`, `no`, or `uncertain`. `uncertain` is a third
nominal category: it is not converted to yes and is retained in agreement and
Cohen's kappa. `reviewer_notes` is required on every row; enter `none` when you
have no additional note. Judge what is displayed and stated, not generator intent.

Definitions:

- `visual_first_hop_correct`: the claim about A relative to B matches the image.
- `bridge_entity_uniquely_identifiable`: text identifies exactly one image B.
- `text_second_hop_correct`: one definite B-to-C cardinal relation is stated.
- `text_second_hop_not_visually_represented`: C and the second hop are not spatially shown.
- `conditions_differ_in_exactly_one_target_relation`: only target relation R2 changes.
- `no_direct_image_text_conflict`: neither condition contradicts a visible fact.
- `joint_answer_unique`: image first hop plus correct evidence yield one candidate.
- the two unimodal-insufficiency fields: that modality alone cannot select one candidate.
- `nl_triples_fact_equivalent`: both serializations state exactly the same fact.
- `critical_error`: yes when any flaw invalidates bridge composition or its paired contrast.

After all rows are complete, fill `reviewer_attestation.yaml`. Use a reviewer code,
not unnecessary personal identity information. Copy the SHA-256 of the received
ZIP from the accompanying `reviewer_2_bundle_sha256.txt`, record timezone-aware
start and completion timestamps, and provide a signed statement under your code.
Return only the completed response CSV and attestation YAML to the designated
private return destination.
